# 🌙 NYX // Lunar Harmony & Fretboard Oracle

An all-in-one interactive music theory reference, multi-instrument chord dictionary, 8-bar song progression workstation, ear-training gym, and Web Audio synth/pedalboard studio.

---

## ✨ Key Features

- **🎸 Multi-Instrument & Bass Clef Switcher**: Switch dynamically between **6-String Guitar** (8 tunings: Standard, Drop D, Eb, D Standard, DADGAD, Open G, Open D, Midwest Emo FACGCE), **Ukulele (G-C-E-A)**, **Mandolin (G-D-A-E)**, and **4-String Bass & Bass Clef (`𝄢`)**.
- **🔮 "Suggest Next Chord" Harmonic Oracle**: Audition smooth voice-led chord transitions (`ii–V–I`, tritone substitutions, deceptive cadences, borrowed minor `ivm6`) and add them straight to your song sheet.
- **✏️ Click-to-Edit Custom Voicings & Reverse Chord Identifier**: Click directly on the chord box or 12-fret neck to build or identify any custom voicing.
- **🎼 8-Bar Song Builder & Multi-Format Exports**: Loop progressions with synced guitar strumming, walking basslines, lead melody tab riffs, and drum grooves across `4/4`, `3/4`, `6/8`, `5/4`, and `7/8` meters. Export as:
  - **Plain Text Chart (`.TXT`)**
  - **Printable PDF Lead Sheet**
  - **2-Track Standard MIDI File (`.MID`)**
  - **Live Studio Audio Recording (`.WAV`)**
  - **Shareable Permalink URL (`#nyx=...`)**
- **🎛️ 4-Pedal Stompbox Chain & Synth ADSR Sculptor**: Eclipse Overdrive, Tidal Chorus, Astral Tempo-Synced Echo, and Lunar Hall Reverb with custom rig saving.
- **🎯 Ear-Training Oracle & Fretboard Star-Hunter**: Blind listening quizzes (Chords, Intervals, Scales) + 30-second fretboard note-finding speed blitz.
- **📱 Mobile-Ready & iOS/Android Web Audio Unlocked**: Automatic touch-gesture silent buffer + playback session unlocker and responsive mobile UI.

---

## 🚀 Deploy to GitHub & Vercel in 60 Seconds

This folder is **already initialized as a Git repository** with an initial commit on the `main` branch.

### Option A: Push to GitHub & Connect to Vercel (Recommended)

1. Create a new empty repository on GitHub: [https://github.com/new](https://github.com/new) (e.g. `nyx-lunar-harmony`).
2. Inside this unzipped folder, link your remote and push:
   ```bash
   git remote add origin https://github.com/<YOUR_USERNAME>/nyx-lunar-harmony.git
   git push -u origin main
   ```
3. Go to [https://vercel.com/new](https://vercel.com/new), import your `nyx-lunar-harmony` GitHub repository, and click **Deploy** (zero configuration needed—`vercel.json` is pre-configured!).

### Option B: Instant CLI Deploy with Vercel CLI

Run this single command inside the unzipped directory:
```bash
npx vercel --prod
```
